package search;

import java.util.LinkedList;

public abstract class AbstractQueueFrontier implements Frontier {
	
	protected final LinkedList<Node> queue;
	protected int maximumNumberofNodesOnFrontier;

	public AbstractQueueFrontier()
	{
		queue = new LinkedList<Node>();
		maximumNumberofNodesOnFrontier = 0;
	}
	
	@Override
	public void clear() {
		// TODO Auto-generated method stub
		queue.clear();
	}

	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return queue.isEmpty();
	}

	@Override
	public void addNode(Node node) {
		// TODO Auto-generated method stub
		queue.add(node);
		if (queue.size() > maximumNumberofNodesOnFrontier)
			maximumNumberofNodesOnFrontier = queue.size();
	}

	public int getMaximumNumberOfNodesOnFrontier()
	{
		return maximumNumberofNodesOnFrontier;
	}
}
