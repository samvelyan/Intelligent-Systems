package search;

public interface Search {
	Node findSolution(State initialState, GoalTest goalTest);
	int getNumberOfNodesInLastSearch();

}
