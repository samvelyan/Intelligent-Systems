package search;

public interface Action {
}
