package search;

public interface Frontier {
	void clear();
	boolean isEmpty();
	Node removeNode();
	void addNode(Node node);
	int getMaximumNumberOfNodesOnFrontier();
}
